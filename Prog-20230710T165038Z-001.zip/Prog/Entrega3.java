package Aula1;
import java.util.Scanner;

public class Entrega3 {
	public static void main (String[] args) {
	int r;
	double a, b, c, p;
	Scanner ent = new Scanner(System.in);
	do {
	System.out.println("Informe um n�mero positivo para o lado A");
	a = ent.nextDouble();
	if (a<0) {
		a=a*-1;
		System.out.println("Estamos medindo para o lado contr�rio, entendi.");
	}
	System.out.println("Informe um n�mero positivo para o lado B");
	b = ent.nextDouble();
	if (b<0) {
		b=b*-1;
		System.out.println("Estamos medindo para o lado contr�rio, entendi.");
	}
	while (a==0|b==0) {
		System.out.println("N�s precisamos de valores v�lidos para medir o pol�gono");
		System.out.println("Informe um n�mero positivo para o lado A");
		a = ent.nextDouble();
		System.out.println("Informe um n�mero positivo para o lado B, diferente de A");
		b = ent.nextDouble();
	}
	c= a*b;
	p= (2*a)+(2*b);
	if (a==b) {
		System.out.println("O quadrade de lado "+a+" possui �rea de "+c+"u� e per�metro de "+p+"u");
	}
	else {
	System.out.println("O ret�ngulo de lado A= "+a+" e lado B= "+b+" possui �rea de "+c+"u� e per�metro de "+p+"u");
	}
	System.out.println("Deseja calcular novamente? Digite 1 para sim e 2 para encerrar.");
	r = ent.nextInt();
	}while (r==1);
		
	}
	
}

